TotemGuard - Paper 1.21.11 - Java 21

Commands:
/totemcheck              Opens online-player GUI (permission totemguard.check)
/totemcheck <player>     Prints session stats
/totempop                Shows your totem pops this session
/totempop <player>       Shows another player's pops this session

Permissions:
totemguard.check (default OP)
totemguard.alerts (default OP)

Important limitations:
- Totem pops are counted from EntityResurrectEvent.
- Rapid offhand changes are only a heuristic. Fast legitimate clicks, lag, and macros can cause false positives.
- This does NOT prove AutoTotem use and does not auto-kick/ban.
- Statistics are session-only and reset on server restart.

Build:
Install Maven and run: mvn package
The jar will be in target/TotemGuard-1.0.0.jar
Requires Java 21 and Paper API 1.21.11.
