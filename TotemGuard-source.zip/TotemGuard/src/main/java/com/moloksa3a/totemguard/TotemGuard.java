package com.moloksa3a.totemguard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class TotemGuard extends JavaPlugin implements Listener {
    private final Map<UUID, Integer> pops = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastSwap = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> fastSwaps = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> flags = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastFlag = new ConcurrentHashMap<>();
    private final Map<UUID, Deque<Long>> swapHistory = new ConcurrentHashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("TotemGuard enabled for Paper 1.21.11");
    }

    @EventHandler public void onPop(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player p)) return;
        pops.merge(p.getUniqueId(), 1, Integer::sum);
    }

    @EventHandler public void onSwap(PlayerSwapHandItemsEvent event) {
        checkSwap(event.getPlayer());
    }

    @EventHandler public void onInventory(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player p)) return;
        if (event.getSlot() == 40 || event.getRawSlot() == 40) checkSwap(p);
    }

    private void checkSwap(Player p) {
        if (!p.getInventory().contains(Material.TOTEM_OF_UNDYING)) return;
        long now = System.currentTimeMillis();
        UUID id = p.getUniqueId();
        long previous = lastSwap.getOrDefault(id, 0L);
        if (previous > 0 && now - previous <= getConfig().getLong("detection.fast-window-ms", 450)) {
            fastSwaps.merge(id, 1, Integer::sum);
            Deque<Long> history = swapHistory.computeIfAbsent(id, k -> new ArrayDeque<>());
            history.addLast(now);
            while (!history.isEmpty() && now - history.peekFirst() > 10000) history.removeFirst();
            int threshold = getConfig().getInt("detection.flag-after-fast-swaps", 8);
            if (history.size() >= threshold && now - lastFlag.getOrDefault(id, 0L) > 15000) {
                flags.merge(id, 1, Integer::sum);
                lastFlag.put(id, now);
                p.sendMessage(color("&c[TotemGuard] &7Rapid offhand changes detected. This is only a suspicion, not proof of AutoTotem."));
                for (Player staff : Bukkit.getOnlinePlayers()) {
                    if (staff.hasPermission("totemguard.alerts")) staff.sendMessage(color("&c[TotemGuard] &f" + p.getName() + " &7has suspicious rapid totem swaps (&c" + flags.get(id) + " flags&7)."));
                }
            }
        }
        lastSwap.put(id, now);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("totempop")) {
            OfflinePlayer target;
            if (args.length > 0) target = Bukkit.getOfflinePlayer(args[0]);
            else if (sender instanceof Player p) target = p;
            else { sender.sendMessage("Usage: /totempop <player>"); return true; }
            int count = pops.getOrDefault(target.getUniqueId(), 0);
            sender.sendMessage(color("&6[TotemGuard] &f" + (target.getName() == null ? "Unknown" : target.getName()) + " &7has &e" + count + " &7totem pops this session."));
            return true;
        }
        if (cmd.equals("totemcheck")) {
            if (!sender.hasPermission("totemguard.check")) { sender.sendMessage(color("&cNo permission.")); return true; }
            if (args.length > 0) { showPlayer(sender, Bukkit.getOfflinePlayer(args[0])); return true; }
            if (!(sender instanceof Player p)) { sender.sendMessage("Use /totemcheck <player> from console."); return true; }
            openGui(p);
            return true;
        }
        return true;
    }

    private void showPlayer(CommandSender sender, OfflinePlayer target) {
        UUID id = target.getUniqueId();
        sender.sendMessage(color("&6&m--------&r &eTotemGuard: " + (target.getName() == null ? "Unknown" : target.getName()) + " &6&m--------"));
        sender.sendMessage(color("&7Totem Pops: &e" + pops.getOrDefault(id, 0)));
        sender.sendMessage(color("&7Fast swaps: &e" + fastSwaps.getOrDefault(id, 0)));
        sender.sendMessage(color("&7Suspicion flags: &c" + flags.getOrDefault(id, 0)));
        sender.sendMessage(color("&8Detection is heuristic; manual review is recommended."));
    }

    private void openGui(Player viewer) {
        List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
        Inventory inv = Bukkit.createInventory(null, Math.max(9, Math.min(54, ((online.size() + 8) / 9) * 9)), color("&8TotemGuard &7| &fPlayers"));
        for (Player target : online) {
            ItemStack item = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) item.getItemMeta();
            meta.setOwningPlayer(target);
            meta.setDisplayName(color("&e" + target.getName()));
            meta.setLore(Arrays.asList(color("&7Totem Pops: &e" + pops.getOrDefault(target.getUniqueId(), 0)), color("&7Fast swaps: &e" + fastSwaps.getOrDefault(target.getUniqueId(), 0)), color("&7Flags: &c" + flags.getOrDefault(target.getUniqueId(), 0)), color("&8Click for details")));
            item.setItemMeta(meta);
            inv.addItem(item);
        }
        viewer.openInventory(inv);
    }

    @EventHandler public void onGuiClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player viewer)) return;
        if (!ChatColor.stripColor(event.getView().getTitle()).startsWith("TotemGuard | Players")) return;
        event.setCancelled(true);
        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType() != Material.PLAYER_HEAD || !(item.getItemMeta() instanceof SkullMeta meta)) return;
        OfflinePlayer target = meta.getOwningPlayer();
        if (target != null) showPlayer(viewer, target);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        lastSwap.remove(id); lastFlag.remove(id); swapHistory.remove(id);
    }

    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
}
